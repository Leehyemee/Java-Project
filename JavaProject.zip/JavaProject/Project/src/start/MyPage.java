package start;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class MyPage extends JFrame {
    private static final long serialVersionUID = 1L;
    private static final String DRIVER = "oracle.jdbc.driver.OracleDriver";
    private static final String URL = "jdbc:oracle:thin:@localhost:1521:xe";
    private static final String USER = "hyemee";
    private static final String PASSWORD = "1234";

    private JTextField idField, passwordField, newPasswordField, usernameField, addressField, phoneField, emailField;
    private JLabel messageLabel;

    public MyPage(UserDto dto) {
        setTitle("My Page");
        setSize(593, 428); // Adjusted size to fit the new fields
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(new BorderLayout());

        // Create and add the form panel
        JPanel panel = new JPanel();
        panel.setBackground(new Color(243, 249, 198));
        panel.setLayout(null);

        // Create UI components
        JLabel idLabel = new JLabel("ID");
        idLabel.setBounds(39, 22, 140, 30);
        idField = new JTextField();
        idField.setBounds(187, 22, 357, 30);
        idField.setText(dto.getId());
        idField.setEditable(false);

        JLabel passwordLabel = new JLabel("비밀번호");
        passwordLabel.setBounds(39, 62, 140, 30);
        passwordField = new JTextField();
        passwordField.setBounds(187, 62, 357, 30);
        passwordField.setEditable(false);
        passwordField.setText(dto.getPassword());

        JLabel newPasswordLabel = new JLabel("새 비밀번호");
        newPasswordLabel.setBounds(39, 102, 140, 30);
        newPasswordField = new JTextField();
        newPasswordField.setBounds(187, 102, 357, 30);
        newPasswordField.setToolTipText("비밀번호는 8자리 이상, 영어와 숫자, 특수문자 모두 포함해야함");

        JLabel usernameLabel = new JLabel("이름");
        usernameLabel.setBounds(39, 142, 140, 30);
        usernameField = new JTextField();
        usernameField.setBounds(187, 142, 357, 30);
        usernameField.setText(dto.getName());

        JLabel addressLabel = new JLabel("주소");
        addressLabel.setBounds(39, 182, 140, 30);
        addressField = new JTextField();
        addressField.setBounds(187, 182, 357, 30);
        addressField.setText(dto.getAddress());

        JLabel phoneLabel = new JLabel("연락처");
        phoneLabel.setBounds(39, 222, 140, 30);
        phoneField = new JTextField();
        phoneField.setBounds(187, 222, 357, 30);
        phoneField.setText(dto.getPhone());

        JLabel emailLabel = new JLabel("Email");
        emailLabel.setBounds(39, 262, 140, 30);
        emailField = new JTextField();
        emailField.setBounds(187, 262, 357, 30);
        emailField.setText(dto.getEmail());

        JButton loadButton = new JButton("내 정보 불러오기");
        loadButton.setBackground(new Color(255, 255, 255));
        loadButton.setBounds(49, 322, 220, 30);
        loadButton.addActionListener(this::loadUserInfo);

        JButton updateButton = new JButton("수정하기");
        updateButton.setBackground(new Color(255, 255, 255));
        updateButton.setBounds(303, 322, 220, 30);
        updateButton.addActionListener(this::updateUserInfo);

        messageLabel = new JLabel("", SwingConstants.CENTER);
        messageLabel.setBounds(59, 362, 470, 30);
        messageLabel.setForeground(Color.RED);

        // Add components to the panel
        panel.add(idLabel);
        panel.add(idField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(newPasswordLabel);
        panel.add(newPasswordField);
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(addressLabel);
        panel.add(addressField);
        panel.add(phoneLabel);
        panel.add(phoneField);
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(loadButton);
        panel.add(updateButton);
        panel.add(messageLabel);

        // Add panel to the frame
        getContentPane().add(panel, BorderLayout.CENTER);

        setVisible(true);
    }

    private void loadUserInfo(ActionEvent e) {
        String password = JOptionPane.showInputDialog(this, "비밀번호를 입력하세요");
        messageLabel.setText(""); // Clear previous message

        if (password == null || password.trim().isEmpty()) {
            messageLabel.setText("Password cannot be empty.");
            return;
        }

        try {
            Class.forName(DRIVER);
            try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
                 PreparedStatement preparedStatement = connection.prepareStatement("SELECT ID, USERNAME, ADDRESS, PHONE, EMAIL FROM USERS WHERE PASSWORD = ?")) {

                preparedStatement.setString(1, password);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        idField.setText(resultSet.getString("ID"));
                        passwordField.setText(password); // Display the password (not secure for production)
                        usernameField.setText(resultSet.getString("USERNAME"));
                        addressField.setText(resultSet.getString("ADDRESS"));
                        phoneField.setText(resultSet.getString("PHONE"));
                        emailField.setText(resultSet.getString("EMAIL"));
                        messageLabel.setText("사용자 정보 수정 가능");
                    } else {
                        messageLabel.setText("User not found or incorrect password.");
                    }
                }
            }
        } catch (Exception ex) {
            messageLabel.setText("정보 수정 오류 발생");
            ex.printStackTrace();
        }
    }

    private void updateUserInfo(ActionEvent e) {
        String userId = idField.getText();
        messageLabel.setText(""); // Clear previous message

        if (userId == null || userId.trim().isEmpty()) {
            messageLabel.setText("불러온 사용자가 없습니다.");
            return;
        }

        String newPassword = newPasswordField.getText().trim();
        String passwordToUpdate = newPassword.isEmpty() ? passwordField.getText() : newPassword; // 새 비밀번호가 비어있다면 기존 비밀번호 사용

        try {
            Class.forName(DRIVER);
            try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
                 PreparedStatement updateStatement = connection.prepareStatement("UPDATE USERS SET PASSWORD = ?, USERNAME = ?, ADDRESS = ?, PHONE = ?, EMAIL = ? WHERE ID = ?")) {

                updateStatement.setString(1, passwordToUpdate); // 새 비밀번호가 있으면 사용, 아니면 기존 비밀번호 사용
                updateStatement.setString(2, usernameField.getText());
                updateStatement.setString(3, addressField.getText());
                updateStatement.setString(4, phoneField.getText());
                updateStatement.setString(5, emailField.getText());
                updateStatement.setString(6, userId);

                int rowsUpdated = updateStatement.executeUpdate();
                if (rowsUpdated > 0) {
                    messageLabel.setText("정보 수정 성공");
                } else {
                    messageLabel.setText("수정 실패, 다시 시도해주세요");
                }
            }
        } catch (Exception ex) {
            messageLabel.setText("정보 수정 오류 발생");
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        // Example user object creation
        UserDto userDto = new UserDto();
        SwingUtilities.invokeLater(() -> new MyPage(userDto));
    }
}
